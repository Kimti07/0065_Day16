function stringLength(){
    var name=$("#firstname").val();
    alert("user name is:" +name.length);
}